<?php
$manifest = array (
    'acceptable_sugar_versions' =>  array (
        'regex_matches' => array(
            '7.8.2.0',
        ),
    ),
    'acceptable_sugar_flavors' => array(
        'ENT'
    ),
    'readme'=>'',
    'key'=>'SOL',
    'author' => 'RT',
    'description' => 'SOL-238-1 add customization for meetings',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => 'SOL-238-1 add customization for meetings', 
    'published_date' => '2017/11/28',
    'type' => 'module',
    'version' => '1.1.0',
    'remove_tables' => '',

);
$installdefs = array (
    'id' => 'meeting_type_customization', 
    'copy' =>
        array (
            array(
                'from' => '<basepath>/SugarModules/custom/modules/Meetings/clients/base/views/record/record.js',
                'to' => 'custom/modules/Meetings/clients/base/views/record/record.js',
            ),
            array(
                'from' => '<basepath>/SugarModules/custom/modules/Meetings/clients/base/views/create/create.js',
                'to' => 'custom/modules/Meetings/clients/base/views/create/create.js',
            ),
        ),

);
