({
    extendsFrom: 'RecordView',
    initialize: function(options) {
        this._super('initialize', [options]);
		
    },
    render: function() {
		this._super('render');
		this.checkUsers();
	},
    checkUsers: function() {
        var self = this;
        var logisticUser = 'no';
        var matchName = 'logistics';
        var csTeam = 'groupe cs';
        var userTeam2 = app.user.get('my_teams');
        _.each(userTeam2,function(e){
            tmName = e.name;
            nam = tmName.toLowerCase();				
            if(nam == matchName || nam == csTeam) { 
                logisticUser = "Yes";
            }
        })
		var usrTyp = app.user.get('type');
        if ( logisticUser == 'Yes' ||  usrTyp == 'admin') {
            $('[data-panelname="LBL_RECORDVIEW_PANEL1"]').show();            
        } else {
		$('[data-panelname="LBL_RECORDVIEW_PANEL1"]').hide();             
        }        		
	},
})
