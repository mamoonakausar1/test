({
    extendsFrom: 'CreateView',

    initialize: function(options) {
		this.plugins = _.union(this.plugins || [], ['AddAsInvitee', 'ReminderTimeDefaults']);
        this._super('initialize', [options]);
		this.checkUser();
    },
    _render: function() {
		this._super('_render');
		this.checkUser_div();
	},
    checkUser_div: function() {
        var self = this;
        var logisticUser = 'no';
        var mdl = this.context.parent.get("module");
        var matchName = 'logistics';
        var csTeam = 'groupe cs';
        var userTeam2 = app.user.get('my_teams');
        _.each(userTeam2,function(e){
            tmName = e.name;
            nam = tmName.toLowerCase();				
            if(nam == matchName || nam == csTeam) { 
                logisticUser = "Yes";
            }
        })
		var usrTyp = app.user.get('type');
		console.log(usrTyp, logisticUser);
        if ( logisticUser == 'Yes' || usrTyp == 'admin') {
            $('div[data-panelname="LBL_RECORDVIEW_PANEL1"]').show();            
        } else {
            $('div[data-panelname="LBL_RECORDVIEW_PANEL1"]').hide();             
        }       		
	},
    checkUser: function() {
        var self = this;
        var logisticUser = 'no';
        var mdl = this.context.parent.get("module");
        var matchName = 'logistics';
        var userTeam2 = app.user.get('my_teams');
        _.each(userTeam2,function(e){
            tmName = e.name;
            nam = tmName.toLowerCase();				
            if(nam == matchName) { 
                logisticUser = "Yes";
            }
        })
        if (mdl == 'Calendar') {
            if (logisticUser == 'no')	{
                self.model.fields['meeting_type2_c'].options = app.lang.getAppListStrings('meeting_typ');
			} else {
                self.model.fields['meeting_type2_c'].options = app.lang.getAppListStrings('meeting_type2_list');
			}		
        }
        		
	},	
})
